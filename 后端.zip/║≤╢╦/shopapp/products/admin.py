from django.contrib import admin

# Register your models here.

from .models import Goods



@admin.register(Goods)
class GoodsAdmin(admin.ModelAdmin):

    list_display=('id','product_name','product_title','product_introduce','product_attribute','product_store_num','product_prices','product_weight','product_place','product_register_time','product_last_update_time','product_images')
    # 按id来排序
    ordering=['-id']
    # 添加右侧筛选功能
    list_filter = ('id','product_name')
    # 搜索字段功能
    search_fields= ('id','product_name','product_store_num','product_prices','product_place')
    # 时间分层功能
    date_hierarchy = 'product_last_update_time'


  
