

from django.http import HttpResponse




def home(request):
    a1="""
    <br>
    <a href='admin/'>管理员主页</a>
    <br>
    <a href='api/str/'>接口1----HttpResponse返回--字符串---str----</a>
    <br>
    <a href='api/dict/'>接口2----Response返回---字典---str</a>
    <br>
    <a href='api/products_list/'>接口3----Response返回--商品列表---products_list--单独app=products</a>
    <br>
    <a href='/upload/upload/gz.jpg'>图片--单独app=products</a>
    <br>
    <a href='api/products_list2/'>接口4----Response返回--商品列表+其它参数---products_list2</a>
    <br>
    <a href='https://mvs.bslmeiyu.com/api/v1/products/popular/'>需要对比参照flutter接口----api/v1/products/popular/</a>
    <br>
    <a href='api/v1/products/popular/'>接口5----完全参照上个网址参数----api/v1/products/popular/--单独app=products_popular</a>
    <br>
    <a href='https://mvs.bslmeiyu.com/api/v1/products/recommended'>需要对比参照flutter接口----api/v1/products/recommended/</a>
    <br>
    <a href='api/v1/products/recommended/'>接口6----完全参照上个网址参数----api/v1/products/recommended/--单独app=products_popular</a>
    
    <br>
    
    
    """
    
    return HttpResponse(a1)