from django.db import models
import datetime

# Create your models here.
class Popular(models.Model):
    # departments=models.ManyToManyField(Department)
    id=models.BigAutoField(primary_key=True,verbose_name="商品id")
    name=models.CharField(max_length=50,verbose_name="商品名字")
    description=models.TextField(null=True,blank=True,max_length=1000,verbose_name="商品描述")
    price=models.IntegerField(null=True,blank=True,default=8,verbose_name="价格")
    stars=models.IntegerField(null=True,blank=True,default=0,verbose_name="星星数")
    img=models.ImageField(upload_to='products_popular',verbose_name="商品图片")
    location=models.CharField(null=True,blank=True,max_length=200 ,verbose_name="产品的产地")
    created_at=models.DateTimeField(null=True,blank=True,auto_now_add=True,verbose_name="首次注册时间")
    updated_at=models.DateTimeField(null=True,blank=True,auto_now=True,verbose_name="最后更新时间")
    type_id=models.IntegerField(null=True,blank=True,default=2,verbose_name="商品类型")
    
    # 标记上传到upload/upload文件夹中

    class Meta:
        verbose_name="商品受欢迎表"
        verbose_name_plural="商品受欢迎表"
    