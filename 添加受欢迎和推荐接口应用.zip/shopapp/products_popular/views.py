from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse

# 
#添加restframework,的api_view装饰器
from rest_framework.decorators import api_view
#添加response 把数据以json格式发送回去，响应
from rest_framework.response import Response

from .models import Popular
# 


# 修改为前端想要的数据格式第A项
@api_view(['GET'])
def products_popular(request):
    popular_list=list(Popular.objects.all().values())
    a={}
    a["total_size"]=6
    a["type_id"]=2
    a["offset"]=0
    a["products"]=popular_list
    return Response(a)

# 修改为前端想要的数据格式第A项
@api_view(['GET'])
def products_recommended(request):
    popular_list=list(Popular.objects.all().values())
    a={}
    a["total_size"]=5
    a["type_id"]=3
    a["offset"]=0
    a["products"]=popular_list
    return Response(a)