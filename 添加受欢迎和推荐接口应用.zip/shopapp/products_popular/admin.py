from django.contrib import admin

# Register your models here.

from .models import Popular



@admin.register(Popular)
class PopularAdmin(admin.ModelAdmin):

    list_display=('id','name','description','price','stars','img','location','created_at','updated_at','type_id',)
    # 按id来排序
    ordering=['-id']
    # 添加右侧筛选功能
    list_filter = ('id','type_id')
    # 搜索字段功能
    search_fields= ('id','name',)
    # 时间分层功能
    date_hierarchy = 'updated_at'


  
