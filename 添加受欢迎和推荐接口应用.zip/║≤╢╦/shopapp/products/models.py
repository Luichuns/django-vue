from django.db import models
import datetime

# Create your models here.
class Goods(models.Model):
    # departments=models.ManyToManyField(Department)
    id=models.BigAutoField(primary_key=True,verbose_name="商品id")
    product_name=models.CharField(max_length=10,verbose_name="商品名字")
    product_title=models.CharField(null=True,blank=True,max_length=30,verbose_name="商品标题")
    product_introduce=models.CharField(null=True,blank=True,max_length=200,verbose_name="商品介绍")
    product_type=models.CharField(null=True,max_length=10,verbose_name="商品类型")
    product_attribute=models.CharField(max_length=5,verbose_name="商品属性")
    product_store_num=models.IntegerField(null=True,blank=True,default=0,verbose_name="库存量")
    product_prices=models.DecimalField(default=8.88,max_digits=8,decimal_places=2,verbose_name="价格")
    product_weight=models.DecimalField(null=True,blank=True,max_digits=10,decimal_places=3,verbose_name="重量")
    product_place=models.CharField(null=True,blank=True,max_length=200 ,verbose_name="产品的产地")
    product_register_time=models.DateTimeField(null=True,blank=True,auto_now_add=True,verbose_name="首次添加商品的注册时间")
    product_last_update_time=models.DateTimeField(null=True,blank=True,auto_now=True,verbose_name="最后更新时间")
    product_images=models.ImageField(upload_to='products',verbose_name="商品图片")
    # 标记上传到upload/upload文件夹中

    class Meta:
        verbose_name="商品目录表"
        verbose_name_plural="商品目录表"
    