

from django.http import HttpResponse




def home(request):
    a1="""
    <br>
    <a href='admin/'>管理员主页</a>
    <br>
    <a href='api/str/'>接口1----HttpResponse返回--字符串---str----</a>
    <br>
    <a href='api/dict/'>接口2----Response返回---字典---str</a>
    <br>
    <a href='api/products_list/'>接口3----Response返回--商品列表---products_list</a>
    <br>
    <a href='/upload/upload/gz.jpg'>图片</a>
    
    """
    
    return HttpResponse(a1)